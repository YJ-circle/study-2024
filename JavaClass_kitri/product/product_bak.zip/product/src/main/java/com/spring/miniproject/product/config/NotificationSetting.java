package com.spring.miniproject.product.config;

public interface NotificationSetting {
	static final String TELEGRAM_BOT_TOKEN = "bot7268759034:AAH2zLUiGX5N0lajymh_BEOlUOpnp9ga5R8";
}
